import jade.core.Agent;
public class FirstAgent extends Agent{
    @Override
    protected void setup (){
        System.out.println("Hello Jade");
        System.out.println("Im first Agent");
        doDelete();
    }
}
